import java.util.ArrayList;

public class StringCalc {
   
   public String str;
   
   public StringCalc() {
      
      str = "1 + 1";
      
   }
   
   public StringCalc(String s) {
      
      str = s;
      
   }
   
   public double getResult() {
      
      int i = 0;
      String[] tokens = str.split(" ");
      ArrayList<Double> numbers = new ArrayList<Double>();
      ArrayList<String> operators = new ArrayList<String>();
      double answer = 0;
      
      for(String token : tokens) {
         
         if(Character.isDigit(token.charAt(0))) 
            numbers.add(Double.parseDouble(token));  
         else
            operators.add(token);
      
      }
      
      
      
      for(String op : operators) {
         
         if(op.equals("*")) { 
         
            answer = numbers.get(i) * numbers.get(i+1);
            numbers.set(i+1, answer);
            numbers.remove(i);
    
         }
         
         if(op.equals("/")) {
         
            answer = numbers.get(i) / numbers.get(i+1);
            numbers.set(i+1, answer);
            numbers.remove(i);
  
         }
         
         i++;
         
         if(numbers.size() <= i+1)
            i = 0;
         
      }
      
      i = 0;
      
      for(String op : operators) {
         
         if(op.equals("+")){
         
            answer = numbers.get(i) + numbers.get(i+1);
            numbers.set(i+1, answer);
            numbers.remove(i);
         
         }
            
         if(op.equals("-")){
         
            answer = numbers.get(i) - numbers.get(i+1);
            numbers.set(i+1, answer);
            numbers.remove(i);
         
         }
         
         i++;
         
         if(op.equals("*"))
            i = 0;
         if(op.equals("/"))
            i = 0;
            
         if(numbers.size() <= i+1)
            i = 0;
         
        
      }
   
      return answer;
   }

}