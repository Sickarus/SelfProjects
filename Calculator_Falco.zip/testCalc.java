public class testCalc {
   
   public static void main(String[] args) {
      
      String str = "2 * 2 * 2";
      StringCalc calc = new StringCalc(str);
      double answer = calc.getResult();
      
      System.out.println(answer);
   
   }

}