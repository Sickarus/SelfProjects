Here is a small little gui calculator I made. 

There are two issues I am aware of that I do not know how to fix with my limited knowledge.
1) The calculator never works the first time.
   In order for it work the user must first use it then clear it.
   I usually do 1+1 then hit = then ce.
2) If the user inputs a sequence thats uses 4 or more operators that vary will result in a wrong answer.
   So 2+2-2-2 will not give 0 and 2+2-2*2/2 will not give 2.

